<?php
$manifest = array (
  'id' => 'uncon217-customizing-awf',
  'name' => 'UnCon 2017 Customizing Advanced Workflow',
  'description' => 'UnCon 2017 Customizing Advanced Workflow',
  'version' => '0.2b',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-09-15 09:13:21',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/JSGroupings/pmsegroupings.php',
      'to' => 'custom/Extension/application/Ext/JSGroupings/pmsegroupings.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/include/javascript/pmse/activity.js',
      'to' => 'custom/include/javascript/pmse/activity.js',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/engine/PMSEElements/PMSEDataEnrichment.php',
      'to' => 'custom/modules/pmse_Inbox/engine/PMSEElements/PMSEDataEnrichment.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-001.jpg',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-001.jpg',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-002.jpg',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-002.jpg',
    ),
    5 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-003.jpg',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-003.jpg',
    ),
    6 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-003.svg',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-003.svg',
    ),
    7 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-004.jpg',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-004.jpg',
    ),
    8 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-005.png',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-005.png',
    ),
    9 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-006.jpg',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-006.jpg',
    ),
    10 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-006.svg',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-006.svg',
    ),
    11 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/img/de-icon-007.png',
      'to' => 'custom/modules/pmse_Inbox/img/de-icon-007.png',
    ),
    12 => 
    array (
      'from' => '<basepath>/src/custom/themes/custom.less',
      'to' => 'custom/themes/custom.less',
    ),
  ),
);
